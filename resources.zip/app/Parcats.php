<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Parcats extends Model
{
    //
}

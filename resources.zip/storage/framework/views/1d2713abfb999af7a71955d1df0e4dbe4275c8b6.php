<?php $__env->startSection('title', "Employee's Details"); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-md-12">
    <div class="card">
      <div class="card-header">
        <h5 class="title"><?php echo e($employee->name); ?>'s Details</h5>
      </div>
      <div class="card-body">
        <form>
          <div class="row">
            <div class="col-md-6 pr-md-1">
              <div class="form-group">
                <label>Name</label>
                <input type="text" class="form-control" value="<?php echo e($employee->name); ?>" />
              </div>
            </div>
            <div class="col-md-6 pr-md-1">
              <div class="form-group">
                <label>Age</label>
                <input type="text" class="form-control" value="<?php echo e($employee->age); ?>" />
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6 pr-md-1">
              <div class="form-group">
                <label>Phone</label>
                <input type="text" class="form-control" value="<?php echo e($employee->phone); ?>" />
              </div>
            </div>
            <div class="col-md-6 pr-md-1">
              <div class="form-group">
                <label>Refer Code</label>
                <input type="text" class="form-control" value="<?php echo e($employee->refer_code); ?>" />
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6 pr-md-1">
              <div class="form-group">
                <label>Education</label>
                <input type="text" class="form-control" value="<?php echo e($employee->education); ?>" />
              </div>
            </div>
          </div>
          
          <div class="row">
            <div class="col-md-6 pr-md-1">
              <div class="form-group">
                <label>Reffered</label>
                <input type="text" class="form-control" value="<?php echo e($employee->referred); ?>" />
              </div>
            </div>
            <div class="col-md-6 pr-md-1">
              <div class="form-group">
                <label>Area</label>
                <input type="text" class="form-control" value="<?php echo e($employee->area); ?>" />
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6 pr-md-1">
              <div class="form-group">
                <label>Post</label>
                <input type="text" class="form-control" value="<?php echo e($employee->post); ?>" />
              </div>
            </div>
            <div class="col-md-6 pr-md-1">
              <div class="form-group">
                <label>Thana</label>
                <input type="text" class="form-control" value="<?php echo e($employee->thana); ?>" />
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6 pr-md-1">
              <div class="form-group">
                <label>District</label>
                <input type="text" class="form-control" value="<?php echo e($employee->district); ?>" />
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12">
              <div class="form-group">
                <label>Address</label>
                <input type="text" class="form-control" value="<?php echo e($employee->address); ?>" />
              </div>
            </div>
          </div>
        </form>
      </div>
      <!-- <div class="card-footer">
        <button type="submit" class="btn btn-fill btn-primary">Save</button>
      </div> -->
    </div>
  </div>
</div>
<div class="row">
  <div class="col-md-12">
    <div class="card ">
      <div class="card-header">
        <h4 class="card-title">Applied Job</h4>
      </div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table tablesorter " id="">
            <thead class=" text-primary">
              <tr>
                <th>
                  Title
                </th>
                <th>
                  Location
                </th>
                <th>
                  Salary
                </th>
                <th >
                  Posted By
                </th>
                <th >
                  Total Apply
                </th>
                <th class="text-center">
                  Action
                </th>
              </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $employee->jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td>
                  <?php echo e($Job->job_title); ?>

                </td>
                <td>
                  <?php echo e($Job->location); ?>

                </td>
                <td>
                  ৳ <?php echo e($Job->salary); ?> / <?php echo e($Job->salary_type); ?>

                </td>
                <td>
                  <?php echo e($Job->employers->phone); ?>

                </td>
                <td>
                  <?php echo e(count($Job->employees)); ?>

                </td>
                <td class="text-center">
                  <a href="<?php echo e(url('jobs/'.$Job->id)); ?>"  class="btn btn-fill btn-primary btn-sm"><i class="fa fa-search"></i></a>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
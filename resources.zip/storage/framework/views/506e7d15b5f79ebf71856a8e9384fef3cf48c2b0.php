<?php $__env->startSection('title', "Educatives"); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-md-12">
    <div class="card">
      <div class="card-header">
        <h5 class="title">ADD EDUCATIVES</h5>
      </div>
      <form action="<?php echo e(route('educatives.store')); ?>" enctype="multipart/form-data" method='POST'>
        <?php echo csrf_field(); ?>
      <div class="card-body">
          <div class="row">
            <div class="col-md-6 pr-md-1">
              <div class="form-group">
                <label>Educative Title</label>
                <input required="" name="title" placeholder="Title" type="text" class="form-control" >
              </div>
            </div>
            <div class="col-md-6 pr-md-1">
              <div class="form-group">
                <label>Thumble</label>
                <input required="" name="thumble" style="position: relative; opacity: 1;" placeholder="Thumble Image" type="file"  />
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6 pr-md-1">
              <div class="form-group">
                <label>Educative Link</label>
                <input required="" name="link" placeholder="Video Link" type="text" class="form-control" >
              </div>
            </div>
            <div class="col-md-6 pr-md-1">
              <button type="submit" class="btn btn-fill btn-primary mt-4">ADD</button>
            </div>
          </div>
      </div>
      </form>
    </div>
  </div>
  <div class="col-md-12">
    <div class="card ">
      <div class="card-header">
        <h4 class="card-title">Educatives List</h4>
      </div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table tablesorter " id="">
            <thead class=" text-primary">
              <tr>
                <th>
                  Title
                </th>
                <th>
                  Thumble
                </th>
                <th>
                  Vedio Link
                </th>
                <th class="text-center">
                  Action
                </th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $educatives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $educative): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td>
                  <?php echo e($educative->title); ?>

                </td>
                <td>
                  <img style="width: 100px" src='img/<?php echo e($educative->thumble); ?>'  />
                </td>
                <td>
                  <a target="_blank" href="<?php echo e($educative->link); ?>"><?php echo e($educative->link); ?></a>
                </td>
                <td class="text-center">
                  <button class="btn btn-sm btn-fill btn-primary"
                  onclick="event.preventDefault();
                    if(confirm('Delete educative')){
                    document.getElementById('delete-form-<?php echo e($educative->id); ?>').submit();
                  }">delete</button>
                  <form id="delete-form-<?php echo e($educative->id); ?>" action="<?php echo e(url('/deledue')); ?>" method="POST" style="display: none;">
                          <?php echo csrf_field(); ?>
                          <input value="<?php echo e($educative->id); ?>" name="id" />
                      </form>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('title', 'Employees'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-md-12">
    <div class="card ">
      <div class="card-header">
        <h4 class="card-title">All Employees</h4>
      </div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table tablesorter " id="">
            <thead class=" text-primary">
              <tr>
                <th>
                  Name
                </th>
                <th>
                  Phone
                </th>
                <th>
                  Age
                </th>
                <th>
                  Gender
                </th>
                <th >
                  EDucation
                </th>
                <th >
                  Refer Code
                </th>
                <th>
                  Referred
                </th>
                <th class="text-center">
                  Action
                </th>
              </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td>
                  <?php echo e($employee->name); ?>

                </td>
                <td>
                  <?php echo e($employee->phone); ?>

                </td>
                <td>
                  <?php echo e($employee->age); ?>

                </td>
                <td>
                  <?php echo e($employee->gender); ?>

                </td>
                <td>
                  <?php echo e($employee->education); ?>

                </td>
                <td>
                  <?php echo e($employee->refer_code); ?>

                </td>
                <td>
                  <?php echo e($employee->referred); ?>

                </td>
                
                <td class="text-center">
                  <a href="<?php echo e(url('employees/'.$employee->id)); ?>"  class="btn btn-fill btn-primary btn-sm"><i class="fa fa-search"></i></a>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
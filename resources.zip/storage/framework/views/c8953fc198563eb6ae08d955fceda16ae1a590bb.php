<?php $__env->startSection('title', "Job's Details"); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-md-12">
    <div class="card">
      <div class="card-header">
        <h5 class="title">Service Details</h5>
      </div>
      <div class="card-body">
          <div class="row">
            <div class="col-md-6 pr-md-1">
              <div class="form-group">
                <label>Name</label>
                <div type="text" class="form-control" >
                  <?php echo e($partnerservices->name); ?>

                </div>
              </div>
            </div>
            <div class="col-md-6 pr-md-1">
              <div class="form-group">
                <label>Mobile</label>
                <div type="text" class="form-control" >
                  <?php echo e($partnerservices->phone); ?>

                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6 pr-md-1">
              <div class="form-group">
                <label>Company Name</label>
                <div type="text" class="form-control" >
                  <?php echo e($partnerservices->compnay_name); ?>

                </div>
              </div>
            </div>
          </div>
          
          <?php
            $profession = json_decode($partnerservices->profession, true);
          ?>
          <div class="row">
            <div class="col-md-6 pr-md-1">
              <div class="form-group">
                <label>Service</label>
                <div type="text" class="form-control" >
                  <?php echo e($profession['cat']); ?>

                </div>
              </div>
            </div>
          </div>
          <?php $__currentLoopData = json_decode($profession['question']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="row">
            <div class="col-md-6 pr-md-1">
              <div class="form-group">
                <label><?php echo e($question->qus); ?></label>
                <div type="text" class="form-control" >
                  <?php echo e($question->ans); ?>

                </div>
              </div>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <div class="row">
            <div class="col-md-12">
              <h5 class="title">Permament Address</h5>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6 pr-md-1">
              <div class="form-group">
                <label>Area</label>
                <div type="text" class="form-control" >
                  <?php echo e($partnerservices->per_area); ?>

                </div>
              </div>
            </div>
            <div class="col-md-6 pr-md-1">
              <div class="form-group">
                <label>Thana</label>
                <div type="text" class="form-control" >
                  <?php echo e($partnerservices->per_thana); ?>

                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6 pr-md-1">
              <div class="form-group">
                <label>District</label>
                <div type="text" class="form-control" >
                  <?php echo e($partnerservices->per_district); ?>

                </div>
              </div>
            </div>
            <div class="col-md-6 pr-md-1">
              <div class="form-group">
                <label>House</label>
                <div type="text" class="form-control" >
                  <?php echo e($partnerservices->per_house); ?>

                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12">
              <h5 class="title">Present Address</h5>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6 pr-md-1">
              <div class="form-group">
                <label>Area</label>
                <div type="text" class="form-control" >
                  <?php echo e($partnerservices->pre_area); ?>

                </div>
              </div>
            </div>
            <div class="col-md-6 pr-md-1">
              <div class="form-group">
                <label>Thana</label>
                <div type="text" class="form-control" >
                  <?php echo e($partnerservices->pre_thana); ?>

                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6 pr-md-1">
              <div class="form-group">
                <label>District</label>
                <div type="text" class="form-control" >
                  <?php echo e($partnerservices->pre_district); ?>

                </div>
              </div>
            </div>
            <div class="col-md-6 pr-md-1">
              <div class="form-group">
                <label>House</label>
                <div type="text" class="form-control" >
                  <?php echo e($partnerservices->pre_house); ?>

                </div>
              </div>
            </div>
          </div>
          <!-- <div class="row">
            <div class="col-md-12">
              <button class="btn btn-sm btn-primary" type="submit">Update</button>
            </div>
          </div> -->
      </div>
      <!-- <div class="card-footer">
        <button type="submit" class="btn btn-fill btn-primary">Save</button>
      </div> -->
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
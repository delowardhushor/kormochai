<?php $__env->startSection('title', "Category"); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-md-12">
    <div class="card">
      <div class="card-header">
        <h5 class="title">ADD Service Category</h5>
      </div>
      <form action="<?php echo e(route('parcats.store')); ?>" method='POST'>
        <?php echo csrf_field(); ?>
      <div class="card-body">
          <div class="row">
            <div class="col-md-6 pr-md-1">
              <div class="form-group">
                <input name="cat" placeholder="Category" type="text" class="form-control" >
              </div>
            </div>
            <div class="col-md-6 pr-md-1">
              <button type="submit" class="btn btn-sm btn-fill btn-primary">Save</button>
            </div>
          </div>
      </div>
      </form>
    </div>
  </div>
  <div class="col-md-12">
    <div class="card ">
      <div class="card-header">
        <h4 class="card-title">Categories List</h4>
      </div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table tablesorter " id="">
            <thead class=" text-primary">
              <tr>
                <th>
                  Category
                </th>
                <th>
                  Questions
                </th>
                <th class="text-center">
                  Action
                </th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $parcats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parcat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td>
                  <?php echo e($parcat->cat); ?>

                </td>
                <td>
                  <?php 
                      $questions = json_decode($parcat->question, true); 
                  ?>
                  <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li><?php echo e($question['qus']); ?></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td class="text-center">

                  <a href="<?php echo e(url('parcats/'.$parcat->id)); ?>"  class="btn btn-fill btn-primary btn-sm"><i class="fa fa-search"></i></a>

                  <button class="btn btn-sm btn-fill btn-primary"
                  onclick="event.preventDefault();
                    if(confirm('Delete parcategory')){
                    document.getElementById('delete-form-<?php echo e($parcat->id); ?>').submit();
                  }">delete</button>
                  <form id="delete-form-<?php echo e($parcat->id); ?>" action="<?php echo e(url('/delparcats')); ?>" method="POST" style="display: none;">
                          <?php echo csrf_field(); ?>
                          <input value="<?php echo e($parcat->id); ?>" name="id" />
                      </form>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
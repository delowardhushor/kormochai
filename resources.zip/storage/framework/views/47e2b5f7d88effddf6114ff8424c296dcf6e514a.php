<?php $__env->startSection('title', "Category"); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-md-12">
    <div class="card">
      <div class="card-header">
        <h5 class="title">ADD Customer Category</h5>
      </div>
      <form action="<?php echo e(route('clicats.store')); ?>" method='POST'>
        <?php echo csrf_field(); ?>
      <div class="card-body">
          <div class="row">
            <div class="col-md-6 pr-md-1">
              <div class="form-group">
                <input name="cat" placeholder="Category" type="text" class="form-control" >
              </div>
            </div>
            <div class="col-md-6 pr-md-1">
              <button type="submit" class="btn btn-sm btn-fill btn-primary">Save</button>
            </div>
          </div>
      </div>
      </form>
    </div>
  </div>
  <div class="col-md-12">
    <div class="card ">
      <div class="card-header">
        <h4 class="card-title">Categories List</h4>
      </div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table tablesorter " id="">
            <thead class=" text-primary">
              <tr>
                <th>
                  Category
                </th>
                <th>
                  Question
                </th>
                <th class="text-center">
                  Action
                </th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $clicats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clicat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td>
                  <?php echo e($clicat->cat); ?>

                </td>
                <td>
                  <?php 
                      $questions = json_decode($clicat->question, true); 
                  ?>
                  <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li><?php echo e($question['qus']); ?></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td class="text-center">
                  <a href="<?php echo e(url('clicats/'.$clicat->id)); ?>"  class="btn btn-fill btn-primary btn-sm"><i class="fa fa-search"></i></a>

                  <button class="btn btn-sm btn-fill btn-primary"
                  onclick="event.preventDefault();
                    if(confirm('Delete clicatsegory')){
                    document.getElementById('delete-form-<?php echo e($clicat->id); ?>').submit();
                  }">delete</button>
                  <form id="delete-form-<?php echo e($clicat->id); ?>" action="<?php echo e(url('/delclicats')); ?>" method="POST" style="display: none;">
                          <?php echo csrf_field(); ?>
                          <input value="<?php echo e($clicat->id); ?>" name="id" />
                      </form>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
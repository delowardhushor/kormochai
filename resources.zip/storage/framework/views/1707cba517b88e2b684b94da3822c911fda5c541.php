<?php $__env->startSection('title', 'Services'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-md-12">
    <div class="card ">
      <div class="card-header">
        <h4 class="card-title">ALL Service</h4>
      </div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table tablesorter " id="">
            <thead class=" text-primary">
              <tr>
                <th>
                  Name
                </th>
                <th>
                  Phone
                </th>
                <th>
                  Company Name
                </th>
                <th >
                  Service / Profession
                </th>
                <th class="text-center">
                  Action
                </th>
              </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $partnerservices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partnerservice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td>
                  <?php echo e($partnerservice->name); ?>

                </td>
                <td>
                  <?php echo e($partnerservice->phone); ?>

                </td>
                <td>
                  <?php echo e($partnerservice->company_name); ?>

                </td>
                <td>
                  <?php 
                    $profession = json_decode($partnerservice->profession, true);
                  ?>
                  <?php echo e($profession['cat']); ?>

                </td>
                <td class="text-center">
                  <a href="<?php echo e(url('partnerservices/'.$partnerservice->id)); ?>"  class="btn btn-fill btn-primary btn-sm"><i class="fa fa-search"></i></a>
                  <a href="<?php echo e(url('printser/'.$partnerservice->id)); ?>"  class="btn btn-fill btn-primary btn-sm"><i class="fa fa-print"></i></a>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>